(function () {
    let response = {
        type: "page",
        body: [
            {
                "type": "service",
                "api":window.buildUrl( "plugin/appto_search/getStats"),
                "body": [
                    {
                        "type": "panel",
                        "title": "搜索引擎大小",
                        "body": "现在是：${databaseSize/1024/1024/1024} GB"
                    },
                    {
                        "type": "panel",
                        "title": "已同步条数",
                        "body": "现在是：${numberOfDocuments}"
                    },
                    {
                        "type": "panel",
                        "title": "总条数",
                        "body": "现在是：${total}"
                    }
                ]
            },
            {
                "type": "form",
                "title": "搜索配置",
                "initApi":window.buildUrl( "plugin/appto_search/getConfig"),
                "api": window.buildUrl("plugin/appto_search/saveConfig"),
                "actions": [
                    {
                        "type": "button",
                        "label": "取消",
                        "actionType": "close",
                    },
                    {
                        "type": "submit",
                        "label": "保存",
                        "level": "primary",
                    }
                ],
                "body": [
                    {
                        "name": "api",
                        "type": "input-text",
                        "label": "搜索接口",
                        "value":"",
                    },
                    {
                        "name": "key",
                        "type": "input-text",
                        "label": "搜索key",
                    },
                    {
                        "name": "state",
                        "type": "switch",
                        "label": "开关"
                    },
                ]
            },

        ]
    };
    window.jsonpCallback && window.jsonpCallback(response);
})();
