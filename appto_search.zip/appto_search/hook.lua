local app = require("app")
local json = require("json")


function getConfig()
    local data = app.readJSON("data.json")
    if data == nil then
        data = {
            api = "",
            key = "",
            state = false,
        }
    end
    return json.encode({
        api = data.api,
        key = data.key,
        state = data.state,
    })
end