local app = require("app")
local inspect = require("inspect")
local json = require("json")
local separator = package.config:sub(1,1)
local global = require("global")
local http = require("http")
local client = http.client()
function getConfig()
    -- 读取 JSON 数据
    --print(globalPluginPath..separator.."data.json")
    local data = app.readJSON("data.json")
    if data==nil then
        data={
            api="",
            key= "",
            state= false,
        }
    end
    return app.outJSON(0,"ok",data)
end

function saveConfig()
    local form =  app.request("form")
    app.saveJSON("data.json",{
        api=rawget(form, "api") ~= nil and form.api or "",
        key=rawget(form, "key") ~= nil and form.key or "",
        state=rawget(form, "state") ~= nil and form.state or false,
    })
    return app.outJSON(0,"ok",nil)
end


function  getStats()
    local config = app.readJSON("data.json")
    local request = http.request("GET", config.api .. "/stats")
    request:header_set("Content-Type", "application/json")
    local access_token = "Bearer "..(rawget(config, "key") ~= nil and config.key or "")
    request:header_set("Authorization", access_token)
    local result, err = client:do_request(request)
    if err~=nil then
        return app.outJSON(1,err)
    end
   local  body= json.decode(result.body)
    local resultTotal, _ = app.mysql():query("select count(vod_id) as count from mac_vod")
    local  total=tonumber(resultTotal.rows[1][1])
    return app.outJSON(0,"ok",{
        databaseSize = body.databaseSize,
        numberOfDocuments = body.indexes.videos.numberOfDocuments,
        total = total,
    })
end
