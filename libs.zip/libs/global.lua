
return {
    apiSecret={
        status=global_config.api_secret.status,
        token=global_config.api_secret.token,
        tokenIv=global_config.api_secret.tokenIv,
    },
    dbConfig={
        mysqlDns=global_config.db_config.mysql_dns,
    },

    pluginPath=global_config.plugin_path

}