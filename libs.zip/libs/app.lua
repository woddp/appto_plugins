local json = require("json")
local app_utils = require("app_utils")
local global = require("global")
local inspect = require("inspect")
local app_cache = require("app_cache")
local db = require("db")
local pathSeparator = package.config:sub(1, 1)
local crypto = require("crypto")

---@param name string
---@return any
local function request(name)
    return appto_request(name)
end
---@param key string
---@param value string
---@return void
local function setHeader(key, value)
    appto_context_set_header(key, value)
end
---@param value string
local function write(value)
    appto_context_write(value)
end
---@param code number
---@param url string
local function redirect(code, url)
    appto_context_redirect(code, url)
end

local function readJSON(filePath)
    filePath = global.pluginPath .. pathSeparator .. filePath
    local content = app_cache.get(crypto.md5(filePath), "")
    if content == "" then
        local file = io.open(filePath, "r")
        if file then
            content = file:read("*a")
            app_cache.set(crypto.md5(filePath), content, 60 * 60 * 24 * 365)
            file:close()
        end
    end
    return json.decode(content)
end

local function saveJSON(filePath, data)
    filePath = global.pluginPath .. pathSeparator .. filePath
    local file = io.open(filePath, "w+")
    if file then
        local content = json.encode(data)
        app_cache.set(crypto.md5(filePath), content, 60 * 60 * 24 * 365)
        file:write(content)
        file:close()
    end
end

local function outJSON(status, msg, data)
    setHeader("Content-Type", "application/json; charset=utf-8")
    write(json.encode({
        status = status,
        msg = msg,
        data = data,
    }))
end

local function apiJSON(code, msg, data, isEnc)
    if isEnc == nil then
        isEnc = true
    end
    local ENCRYPTION = 0
    --if global.apiSecret.status and data~=nil and isEnc  then
    --    ENCRYPTION=1
    --    if  type(data)== "table"  then
    --     data=json.encode(data)
    --    end
    --    data=app_utils.aesCBCEncrypt(data,global.apiSecret.token,global.apiSecret.tokenIv)
    --end
    local content = json.encode({
        code = code,
        msg = msg,
        data = data,
        ENCRYPTION = ENCRYPTION,
    })
    setHeader("Content-Type", "application/json; charset=utf-8")
    write(content)
    return
end

local function mysql()
    local config = {
        shared = true, -- share connections between lua states
        max_connections = 10, -- max connection (if you open shared connection with different max_connections - first win)
        read_only = false, -- must execute read-write query
    }
    return db.open("mysql", global.dbConfig.mysqlDns, config)
end

local function getPluginInfo()

    local file = io.open(global.pluginPath .. pathSeparator .. "info.ini", "r")
    -- 创建一个空表来存储配置项
    local config = {
        state = 0
    }
    if file then
        -- 逐行读取文件内容
        for line in file:lines() do
            -- 使用正则表达式或字符串分割操作提取配置项和值
            local key, value = line:match("^%s*(.-)%s*=%s*(.-)%s*$")
            -- 如果成功匹配到了配置项和值，则将其存储到config表中
            if key and value then
                config[key] = value
            end
        end
        -- 关闭文件
        file:close()
    end

    return config
end

return {
    readJSON = readJSON,
    saveJSON = saveJSON,
    outJSON = outJSON,
    mysql = mysql,
    apiJSON = apiJSON,
    getPluginInfo = getPluginInfo,
    request = request,
    context = {
        setHeader = setHeader,
        write = write,
        redirect = redirect
    },

}