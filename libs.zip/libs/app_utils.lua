local appto_utils = require("appto_utils")

---@param cipherText string
---@param key string
---@return string
local  function aesCBCDecrypt(cipherText,key,iv)
    return    appto_utils.aesCBCDecrypt(cipherText,key,iv)
end
---@param cipherText string
---@param key string
---@return string
local  function aesCBCEncrypt(cipherText,key,iv)
    return    appto_utils.aesCBCEncrypt(cipherText,key,iv)
end

---计算分页
---@param total number
---@param page number
---@return number
local  function paging(total,page)
    offset = (page - 1) * total;
    return    offset
end


return{
    aesCBCDecrypt=aesCBCDecrypt,
    aesCBCEncrypt=aesCBCEncrypt,
    paging=paging
}