local appto_redis = require("appto_redis")

---@return string
---@param key string
---@param default string
local function get(key,default)
  return appto_redis.get(key, default)
end
---@return void
---@param key string
---@param value string
---@param expire number
local function set(key,value,expire)
    return appto_redis.set(key, value,expire)
end
---@param key string
---@return string
local function del(key)
    return appto_redis.del(key)
end
---@param key string
---@param index number
---@return string
local function incrBy(key,index)
    return appto_redis.incrBy(key, index)
end
--@param key string
---@return number
local function exists(key)
    return appto_redis.exists(key)
end
--@param key string
--@param exp number
---@return number
local function expire(key,exp)
    return appto_redis.expire(key,exp)
end

return{
    get=get,
    set=set,
    del=del,
    incrBy=incrBy,
    exists=exists,
    expire=expire,
}