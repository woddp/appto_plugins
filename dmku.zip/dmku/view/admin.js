(function () {


    let response = {
        type: "page",
        body: [
            {
                "type": "form",
                "title": "弹幕配置",
                "initApi":window.buildUrl( "plugin/dmku/getConfig"),
                "api": window.buildUrl("plugin/dmku/saveConfig"),
                "actions": [
                    {
                        "type": "button",
                        "label": "取消",
                        "actionType": "close",
                    },
                    {
                        "type": "submit",
                        "label": "保存",
                        "level": "primary",
                    }
                ],
                onEvent: {

                },
                "body": [
                    {
                        "name": "api",
                        "type": "input-text",
                        "label": "弹幕接口",
                        "value":"https://dmku.thefilehosting.com/?url=",
                    },
                    {
                        "name": "field",
                        "type": "input-text",
                        "label": "返回字段",
                        "desc":"接口返回弹幕列表的key",
                        "value":"danmuku",
                    },
                    {
                        "type": "select",
                        "name": "vod_play",
                        "label": "播放器",
                        "desc":"请选能被获取弹幕的播放源，不要选择无法获取弹幕的播放源",
                        "required": true,
                        "checkAll": true,
                        "multiple": true,
                        "source": {
                            "method": "get",
                            "url":  window.buildUrl("plugin/dmku/getVodPlay"),
                            adaptor: function (payload, response) {
                                return  AdaptorPayloadTransform(payload,payload.data,"From","Show")
                            },
                        }
                    },
                    getInfoAlert("每个字段对应弹幕返回的位置，从0开始"),
                    {
                        "type": "input-number",
                        "name": "second",
                        "value": 0,
                        "min":0,
                        "label": "时间"
                    },
                    {
                        "type": "input-number",
                        "name": "color",
                        "min": 0,
                        "value": 3,
                        "label": "颜色"
                    },
                    {
                        "type": "input-number",
                        "name": "position",
                        "min": 0,
                        "label": "位置",
                        "value": 1,
                    },
                    {
                        "type": "input-number",
                        "name": "content",
                        "min": 0,
                        "value": 4,
                        "label": "内容"
                    },
                    {
                        "type": "input-number",
                        "name": "remove_before_num",
                        "value": 0,
                        "label": "移除前面几条弹幕数据",
                        "desc": "移除前面无用的几条弹幕数据，不同接口设置不同"
                    },
                    {
                        "type": "input-number",
                        "name": "request_timeout",
                        "value": 20,
                        "label": "超时时间",
                        "desc": "单位为秒，弹幕接口请求超时时间"
                    },
                    {
                        "type": "input-number",
                        "name": "cache_time",
                        "value": 3600,
                        "desc":"单位为秒，弹幕接口缓存多少秒,本地弹幕不缓存",
                        "label": "弹幕缓存时间"
                    },
                ]
            },

        ]
    };
    window.jsonpCallback && window.jsonpCallback(response);
})();
