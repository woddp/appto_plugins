local app = require("app")
local inspect = require("inspect")
local json = require("json")
local separator = package.config:sub(1,1)
local global = require("global")
function getConfig()
    -- 读取 JSON 数据
    --print(globalPluginPath..separator.."data.json")
    local data = app.readJSON("data.json")
    if data==nil then
        data={
            api="",
            field= "",
            vod_play= "",
            second=0,
            color=3,
            position=1,
            content=4,
            remove_before_num=0,
            request_timeout=20,
            cache_time=3600,
        }
    end
    return app.outJSON(0,"ok",data)
end

function saveConfig()
    local form =  app.request("form")
    app.saveJSON("data.json",{
        api=rawget(form, "api") ~= nil and form.api or "",
        field=rawget(form, "field") ~= nil and form.field or "danmuku",
        vod_play=rawget(form, "vod_play") ~= nil and form.vod_play or "",
        second=rawget(form, "second") ~= nil and form.second or 0,
        color=rawget(form, "color") ~= nil and form.color or 3,
        position=rawget(form, "position") ~= nil and form.position or 1,
        content=rawget(form, "content") ~= nil and form.content or 4,
        remove_before_num=rawget(form, "remove_before_num") ~= nil and form.remove_before_num or 0,
        request_timeout=rawget(form, "request_timeout") ~= nil and form.request_timeout or 20,
        cache_time=rawget(form, "cache_time") ~= nil and form.cache_time or 3600,
    })
    return app.outJSON(0,"ok",nil)
end

function getVodPlay()
    return app.outJSON(0,"ok",appto_config('vod_play'))
end
