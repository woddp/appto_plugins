local app = require("app")
local json = require("json")


function getConfig()
    local data = app.readJSON("data.json")
    if data == nil then
        data = {
            api = "",
            field = "",
            vod_play = "",
            second =0,
            color = 3,
            position = 1,
            content = 4,
            remove_before_num = 0,
            request_timeout =20,
            cache_time = 3600,
        }
    end
    return json.encode({
        api = data.api,
        field = data.field,
        vod_play = data.vod_play,
        second = data.second,
        color = data.color,
        position =  data.position,
        content =  data.content,
        remove_before_num = data.remove_before_num,
        request_timeout =data.request_timeout,
        cache_time = data.cache_time,
    })
end