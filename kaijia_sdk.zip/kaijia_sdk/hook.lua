local app = require("app")
local json = require("json")


function getConfig()
    local data = app.readJSON("data.json")

    return json.encode(data)
end