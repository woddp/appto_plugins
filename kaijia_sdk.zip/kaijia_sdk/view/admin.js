(function () {
    function sdkConfig(config) {
        const info = [
            {
                type: "input-text",
                name: "app_id",
                label: "应用/媒体ID",
            },
        ];
        if (config.withAppName) {
            info.push({
                type: "input-text",
                name: "app_name",
                label: "应用名称",
            });
        }
        return [
            {
                type: "panel",
                title: "授权设置",
                body: info
            },
            {
                type: "panel",
                title: "开屏广告",
                body:
                    {
                        type: "input-text",
                        name: "splash_ad",
                        label: "开屏广告ID",
                    },
            },
            {
                type: "panel",
                title: "横幅/banner广告",
                body: [
                    {
                        type: "input-text",
                        name: "banner_ad_for_mine_tab",
                        label: "我的页横幅广告ID",
                    },
                    {
                        type: "input-text",
                        name: "banner_ad_for_play_page",
                        label: "播放页横幅广告ID",
                    },
                    {
                        type: "input-text",
                        name: "banner_ad_for_search_page",
                        label: "搜索页横幅广告ID",
                    },
                    {
                        type: "input-text",
                        name: "banner_ad_for_search_result_page",
                        label: "搜索结果页横幅广告ID",
                    },
                    {
                        type: "input-text",
                        name: "banner_ad_for_download_page",
                        label: "下载页横幅广告ID",
                    },
                    {
                        type: "input-text",
                        name: "banner_ad_for_record_page",
                        label: "历史页横幅广告ID",
                    }
                ]
            },
            {
                type: "panel",
                title: "信息流广告",
                body: [
                    {
                        "name": "static",
                        "type": "static",
                        "label": "",
                        "value": "请申请: " + config.feedAdType
                    },
                    {
                        type: "input-text",
                        name: "feed_ad_for_mine_tab",
                        label: "我的页信息流广告ID",
                    },
                    {
                        type: "input-text",
                        name: "feed_ad_for_play_page",
                        label: "播放页信息流广告ID",
                    },
                    {
                        type: "input-text",
                        name: "feed_ad_for_search_page",
                        label: "搜索页信息流广告ID",
                    },
                    {
                        type: "input-text",
                        name: "feed_ad_for_search_result_page",
                        label: "搜索结果页信息流广告ID",
                    },
                    {
                        type: "input-text",
                        name: "feed_ad_for_download_page",
                        label: "下载页信息流广告ID",
                    },
                    {
                        type: "input-text",
                        name: "feed_ad_for_record_page",
                        label: "历史页信息流广告ID",
                    }
                ]
            },
            {
                type: "panel",
                title: "激励广告",
                body: [
                    {
                        type: "input-text",
                        name: "reward_ad_before_play",
                        label: "播放前激励广告ID",
                    },
                    {
                        type: "input-text",
                        name: "reward_ad_before_download",
                        label: "下载前激励广告ID",
                    },
                    {
                        type: "input-text",
                        name: "reward_ad_before_push",
                        label: "催更前激励广告ID",
                    },
                    {
                        type: "input-text",
                        name: "reward_ad_site_free",
                        label: "其它激励广告ID",
                    },
                ]
            },
            {
                type: "panel",
                title: "插屏广告",
                body: [
                    {
                        type: "input-text",
                        name: "insert_ad_for_launch",
                        label: "启动完毕插屏广告ID",
                    },
                    {
                        type: "input-text",
                        name: "insert_ad_for_home",
                        label: "首页插屏广告ID",
                    },
                    {
                        type: "input-text",
                        name: "insert_ad_for_daily",
                        label: "排期表插屏广告ID",
                    },
                    {
                        type: "input-text",
                        name: "insert_ad_for_rank",
                        label: "排行榜插屏广告ID",
                    },
                    {
                        type: "input-text",
                        name: "insert_ad_for_mine",
                        label: "我的页插屏广告ID",
                    },
                    {
                        type: "input-text",
                        name: "insert_ad_for_search",
                        label: "搜索页插屏广告ID",
                    },
                    {
                        type: "input-text",
                        name: "insert_ad_for_video",
                        label: "播放页插屏广告ID",
                    },
                    {
                        type: "input-text",
                        name: "insert_ad_for_record",
                        label: "历史页插屏广告ID",
                    },
                    {
                        type: "input-text",
                        name: "insert_ad_for_download",
                        label: "下载页插屏广告ID",
                    },
                    {
                        type: "input-text",
                        name: "insert_ad_for_paused",
                        label: "播放器暂停插屏广告ID",
                    },
                    {
                        type: "input-text",
                        name: "insert_ad_for_resume",
                        label: "应用恢复插屏广告ID",
                    },
                ]
            },

        ];
    }
    let response = {
        type: "page",
        body: [   {
            "type": "form",
            "title": "",
            "initApi": window.buildUrl( "plugin/kaijia_sdk/getConfig"),
            "wrapWithPanel": true,
            "api":  window.buildUrl( "plugin/kaijia_sdk/saveConfig"),
            "body": [
                {
                    type: 'alert',
                    level: 'info',
                    showIcon: true,
                    body: '<b>铠甲广告</b>'
                },
                ...sdkConfig({
                    feedAdType: '模板广告',
                }),
            ]
        }]
    };
    window.jsonpCallback && window.jsonpCallback(response);
})();
