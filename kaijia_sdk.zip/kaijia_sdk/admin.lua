local app = require("app")
local inspect = require("inspect")
local json = require("json")
local separator = package.config:sub(1,1)
local global = require("global")
function getConfig()
    local data = app.readJSON("data.json")
    if data==nil then
        data={}
    end
    return app.outJSON(0,"ok",data)
end

function saveConfig()
    local form =  app.request("form")
    app.saveJSON("data.json",form)
    return app.outJSON(0,"ok",nil)
end

