(function () {


    let response = {
        type: "page",
        body: [
            {
                "type": "form",
                "title": "激励配置",
                "initApi":window.buildUrl( "plugin/see_ad_award/getConfig"),
                "api": window.buildUrl("plugin/see_ad_award/saveConfig"),
                "actions": [
                    {
                        "type": "button",
                        "label": "取消",
                        "actionType": "close",
                    },
                    {
                        "type": "submit",
                        "label": "保存",
                        "level": "primary",
                    }
                ],
                onEvent: {
                    "submitSucc": {
                        "actions": [
                            {
                                "actionType": "custom",
                                "script": `
                                        console.log(1231);\n //event.stopPropagation();`
                            }
                        ]
                    }
                },
                "body": [
                    {
                        "name": "incentive_switch",
                        "type": "switch",
                        "label": "启用激励系统",
                        "value": false,
                    },
                    {
                        "name": "incentive_btn_switch",
                        "type": "switch",
                        "label": "卡片按钮是否更改为激励",
                        "value": false,
                        "desc": "配合主题修改按钮文案为赞助可以触发看激励视频，不启用可以自定义 /event/see_ad_award 实现触发看激励视频",

                    },
                    {
                        "name": "incentive_type",
                        "type": "radios",
                        "label": "激励类型",
                        "value": 1,
                        "options": [
                            {
                                "label": "需要登录",
                                "value": 1
                            },
                            {
                                "label": "无需登录",
                                "value": 2
                            }
                        ]

                    },
                    {
                        "type": "group",
                        "visibleOn": "this.incentive_type == 1",
                        "label": "需要登录",
                        "direction": "vertical",
                        "body": [
                            {
                                "type": "input-number",
                                "name": "incentive_award",
                                "min": 0,
                                "label": "激励奖励积分 （为0不奖励）"
                            },
                            {
                                "label": "激励奖励vip",
                                "type": "select",
                                "name": "incentive_vip",
                                "value":0,
                                "source":window.buildUrl("plugin/see_ad_award/getGroup"),
                            },
                            {
                                "type": "input-number",
                                "name": "incentive_vip_time",
                                hiddenOn: "this.incentive_vip <= 2",
                                "min": 0,
                                "precision": 2,
                                "label": "激励奖励vip时长",
                                "desc": "为0为不奖励，单位为秒"
                            },

                        ]
                    },
                    {
                        "type": "group",
                        "visibleOn": "this.incentive_type == 2",
                        "label": "无需登录",
                        "body": [
                            {
                                "type": "input-number",
                                "name": "incentive_free_ad_time",
                                "min": 0,
                                "label": "奖励免广告时长",
                                "desc": "为0为不奖励，单位为秒"
                            },
                        ]
                    },

                    {
                        "type": "input-number",
                        "name": "incentive_count",
                        "min": 0,
                        "label": "每天激励次数"
                    },
                    {
                        "type": "input-text",
                        "name": "incentive_before_tip",
                        "min": 0,
                        "label": "观看激励前弹出文案"
                    },
                    {
                        "type": "input-text",
                        "name": "incentive_after_tip",
                        "min": 0,
                        "label": "观看激励后弹出文案"
                    },
                    {
                        "type": "input-text",
                        "name": "incentive_interrupt_tip",
                        "min": 0,
                        "label": "观看激励中断弹出文案"
                    },
                ]
            },

        ]
    };
    window.jsonpCallback && window.jsonpCallback(response);
})();
