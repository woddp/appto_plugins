local app = require("app")
local inspect = require("inspect")
local json = require("json")
local separator = package.config:sub(1,1)

function getConfig()
    -- 读取 JSON 数据
    --print(globalPluginPath..separator.."data.json")
    local data = app.readJSON("data.json")
    if data==nil then
        data={
            incentive_switch=false,
            incentive_btn_switch=false,
            incentive_award=0,
            incentive_vip=1,
            incentive_vip_time=0,
            incentive_count=0,
            incentive_before_tip="",
            incentive_after_tip="",
            incentive_interrupt_tip="",
        }
    end
    return app.outJSON(0,"ok",data)
end

function saveConfig()
    local form =  app.request("form")
    app.saveJSON("data.json",{
        incentive_switch=rawget(form, "incentive_switch") ~= nil and form.incentive_switch or false,
        incentive_btn_switch=rawget(form, "incentive_btn_switch") ~= nil and form.incentive_btn_switch or false,
        incentive_award=rawget(form, "incentive_award") ~= nil and form.incentive_award or 0,
        incentive_vip=rawget(form, "incentive_vip") ~= nil and form.incentive_vip or 1,
        incentive_vip_time=rawget(form, "incentive_vip_time") ~= nil and form.incentive_vip_time or 0,
        incentive_count=rawget(form, "incentive_count") ~= nil and form.incentive_count or 0,
        incentive_before_tip=rawget(form, "incentive_before_tip") ~= nil and form.incentive_before_tip or "",
        incentive_after_tip=rawget(form, "incentive_after_tip") ~= nil and form.incentive_after_tip or "",
        incentive_interrupt_tip=rawget(form, "incentive_interrupt_tip") ~= nil and form.incentive_interrupt_tip or "",
        incentive_type=rawget(form, "incentive_type") ~= nil and form.incentive_type or 1,
        incentive_free_ad_time=rawget(form, "incentive_free_ad_time") ~= nil and form.incentive_free_ad_time or 0,
    })
    return app.outJSON(0,"ok",nil)
end

function getGroup()

    local  result,err=app.mysql():query("SELECT group_id,group_name FROM `mac_group` where group_status = 1  ")


    if err~=nil then
        return app.outJSON(0,"ok",nil)
    end
    local groups = {}
    for _, row in pairs(result.rows) do
        local group = {}
        row=row;
        for id, name in pairs(result.columns) do
            if name=="group_id" then
                group["value"]=tonumber(row[id])
            end
            if name=="group_name" then
                group["label"]=row[id]
            end
        end
        table.insert(groups, group)
    end
    return app.outJSON(0,"ok",groups)
end
