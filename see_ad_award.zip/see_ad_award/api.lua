local app = require("app")
local app_cache = require("app_cache")
local json = require("json")
local crypto = require("crypto")
local app_utils = require("app_utils")
local inspect = require("inspect")
local aeskey="5D2mOQPbNpIhgJ3TxMptCpV3J00qFWMb"

local cacheKey = "see_ad_award:"

function getConfig()
    local data = app.readJSON("data.json")
    if data == nil then
        data = {
            incentive_switch = false,
            incentive_btn_switch = false,
            incentive_before_tip = "",
            incentive_type = 1,
            incentive_free_ad_time =0,
            incentive_count =0,
            incentive_after_tip = "",
            incentive_interrupt_tip = "",
        }
    end
    return json.encode({
            incentive_switch = data.incentive_switch,
            incentive_btn_switch = data.incentive_btn_switch,
            incentive_before_tip = data.incentive_before_tip,
            incentive_after_tip = data.incentive_after_tip,
            incentive_count =  data.incentive_count,
            incentive_interrupt_tip =  data.incentive_interrupt_tip,
            incentive_type =rawget(data, "incentive_type") ~= nil and data.incentive_type or 1,
            incentive_free_ad_time =rawget(data, "incentive_free_ad_time") ~= nil and data.incentive_free_ad_time or 0,
            incentive_aes =  aeskey,
    })
end

-- 获取签名
function getSignature()
    local userInfo = app.request("userInfo")
    local config = app.readJSON("data.json")
    local currentTimestamp = os.time()
    if (userInfo.UserId <= 0) and (config.incentive_type==1) then
        return app.apiJSON(0, "请登录", nil)
    end

    local data = {
        time = currentTimestamp,
        userId = userInfo.UserId,
        md5="",
    }
    data.md5 = crypto.md5(currentTimestamp)


    app_cache.set(cacheKey .. data.md5, "ok", 120)
    local content = app_utils.aesCBCEncrypt(json.encode(data),aeskey,'1238389483762837')
    return app.apiJSON(1, "ok", content,false)

end
function complete()
    local form =  app.request("form")
    local userInfo =  app.request("userInfo")
    if (userInfo.UserId <= 0) then
        return app.apiJSON(422, "请登录", nil)
    end
    --读取配置文件
    local config = app.readJSON("data.json")
    if config==nil then
        return app.apiJSON(0, "激励系统未配置", nil)
    end



    if not config.incentive_switch or app.getPluginInfo().state==0 then
        return app.apiJSON(0, "激励系统未启用", nil)
    end

    local key_ = rawget(form, "key") ~= nil and form.key or ""
    if key_ == "" then
        return app.apiJSON(0, "参数错误", nil)
    end

    local result = app_cache.get(cacheKey .. key_, "")
    if result ~= "ok" then
        return app.apiJSON(0, "验证失败", nil)
    end

    app_cache.del(cacheKey .. key_)

    local currentTime = os.time()
    local midnight = os.time({ year = os.date("%Y"), month = os.date("%m"), day = os.date("%d"), hour = 23, min = 59, sec = 59 })
    local secondsRemaining = midnight - currentTime

    local todayKey = cacheKey .. 'user:' .. userInfo.UserId

    if tonumber(app_cache.get(todayKey, "0")) >= config.incentive_count then
        return app.apiJSON(0, "今日激励次数已完成", nil)
    end

    if app_cache.exists(todayKey) <= 0 then
        app_cache.set(todayKey, 1, secondsRemaining)
    else
        app_cache.incrBy(todayKey, 1);
    end


    --奖励积分
    if config.incentive_award > 0 then
        app.mysql():exec("UPDATE `mac_user` SET `user_points` = `user_points`+" .. config.incentive_award .. " WHERE `user_id` = " .. userInfo.UserId)
    end


    --奖励vip 时常 天
    if config.incentive_vip_time > 0 then
        local seconds = config.incentive_vip_time
        app.mysql():exec("UPDATE `mac_user` SET  group_id=".. config.incentive_vip..",`user_end_time` = IF(user_end_time IS NULL OR user_end_time < UNIX_TIMESTAMP(), UNIX_TIMESTAMP()  , user_end_time) +" .. seconds .. " WHERE `user_id` = " .. userInfo.UserId)
    end

    return app.apiJSON(1, config.incentive_after_tip, nil)

end


