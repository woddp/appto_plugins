local appto = require("app")
local inspect = require("inspect")
local json = require("json")
local separator = package.config:sub(1,1)

function getConfig()
    -- 读取 JSON 数据
    local data = appto.readJSON(globalPluginPath..separator.."data.json")
    if data==nil then
        data={
            appid="",
            merchant_private_key="",
            alipay_public_key="",
        }
    end
    return appto.outJSON(0,"ok",data)
end

function saveConfig()
    local form= request("form")

    print(inspect(form))
    appto.saveJSON(globalPluginPath..separator.."data.json",{
        appid=rawget(form, "appid") ~= nil and form.appid or "",
        merchant_private_key=rawget(form, "merchant_private_key") ~= nil and form.merchant_private_key or "",
        alipay_public_key=rawget(form, "alipay_public_key") ~= nil and form.alipay_public_key or "",
    })
    return appto.outJSON(0,"ok",nil)
end
