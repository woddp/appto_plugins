(function () {


    let response = {
        type: "page",
        body: [
            {
                "type": "form",
                "title": "激励配置",
                "initApi": "/admin/plugin/new_alipay/getConfig",
                "api": "/admin/plugin/new_alipay/saveConfig",
                "actions": [
                    {
                        "type": "button",
                        "label": "取消",
                        "actionType": "close",
                    },
                    {
                        "type": "submit",
                        "label": "保存",
                        "level": "primary",
                    }
                ],
                onEvent: {
                    "submitSucc": {
                        "actions": [
                            {
                                "actionType": "custom",
                                "script": `
                                        console.log(1231);\n //event.stopPropagation();`
                            }
                        ]
                    }
                },
                "body": [
                    {
                        "type": "input-text",
                        "name": "appid",
                        "label": "APPID"
                    },
                    {
                        "type": "input-text",
                        "name": "merchant_private_key",
                        "label": "商户密钥"
                    },
                    {
                        "type": "input-text",
                        "name": "alipay_public_key",
                        "label": "支付宝公钥"
                    },
                ]
            },

        ]
    };
    window.jsonpCallback && window.jsonpCallback(response);
})();
