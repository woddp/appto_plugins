local app = require("app")
local inspect = require("inspect")
local signature =require("signature")
local separator = package.config:sub(1, 1)

function pay(order)
    app.context.setHeader("Content-Type","text/html; charset=utf-8")
    orderPayType = rawget(order, "OrderPayType") ~= nil and order.OrderPayType or ""
    local splitResult = {}
    for word in orderPayType:gmatch("[^,]+") do
        table.insert(splitResult, word)
    end

    if #splitResult ~= 2 then
        return    app.context.write( "订单参数错误")

    end

    local payType = splitResult[2]

    local data = app.readJSON( "data.json")
    api = rawget(data, "api") ~= nil and data.api or ""
    pid = rawget(data, "pid") ~= nil and data.pid or 0
    key = rawget(data, "key") ~= nil and data.key or ""
    pay_buy_vip_select = rawget(data, "pay_buy_vip_select") ~= nil and data.pay_buy_vip_select or {  }
    local parameter = {
        pid = "qwe",
        type = payType,
        notify_url = app.request("domain") .. '/apptov5/payment/notify/epay',
        return_url = app.request("domain") .. '/apptov5/payment/return/epay',
        out_trade_no = order.OrderCode,
        name = order.OrderRemarks,
        money = "1.00",
    }
    params= signature.createSign(parameter,key)

    app.context.write("<script>location.href='"..api.."/submit.php?"..signature.httpBuildQuery(params).."'</script>")
end

function notify()
    local  query= app.request("query")

    local  out_trade_no = rawget(query, "out_trade_no") ~= nil and data.query or ""
    local  trade_no = rawget(query, "trade_no") ~= nil and data.trade_no or ""
    local  trade_status = rawget(query, "trade_status") ~= nil and data.trade_status or ""
    local  type = rawget(query, "type") ~= nil and data.type or ""

    if trade_status~="TRADE_SUCCESS" then
        app.context.setHeader("Content-Type","text/html; charset=utf-8")
        app.context.write("fail")
    end

end

function returnPage()
    app.context.setHeader("Content-Type","text/html; charset=utf-8")
    app.context.write("ok")
end

