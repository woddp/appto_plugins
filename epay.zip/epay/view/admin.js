(function () {
    let response = {
        type: "page",
        body:{
            "type": "tabs",
            "swipeable": true,
            "tabs": [
                {
                    "title": "支付账户配置",
                    "tab": {
                        "type": "form",
                        "title": "激励配置",
                        "initApi": "/admin/plugin/epay/getConfig?type=account",
                        "api": "/admin/plugin/epay/saveConfig?type=account",
                        "actions": [
                            {
                                "type": "button",
                                "label": "取消",
                                "actionType": "close",
                            },
                            {
                                "type": "submit",
                                "label": "保存",
                                "level": "primary",
                            }
                        ],
                        onEvent: {
                            "submitSucc": {
                                "actions": [
                                    {
                                        "actionType": "custom",
                                        "script": `
                                        console.log(1231);\n //event.stopPropagation();`
                                    }
                                ]
                            }
                        },
                        "body": [
                            {
                                "type": "input-text",
                                "name": "api",
                                "label": "支付网关",
                                "required":true,
                            },
                            {
                                "type": "input-text",
                                "name": "pid",
                                "label": "商户ID",
                                "required":true,
                            },
                            {
                                "type": "input-text",
                                "name": "key",
                                "label": "商户密钥",
                                "required":true,
                            },
                            {
                                "name": "pay_buy_vip_select",
                                "label": "支付方式",
                                "type": "input-array",
                                "required":true,
                                "value": [],
                                "desc": "alipay:支付宝,tenpay:财付通,\n" +
                                    "qqpay:QQ钱包,wxpay:微信支付,\n" +
                                    "alipaycode:支付宝扫码,jdpay:京东支付   多个逗号分割",
                                "inline": true,
                                "items": {
                                    "type": "input-text",
                                    "clearable": false
                                }
                            },
                        ]
                    },
                },
                {
                    "title": "支付参数配置",
                    "tab": {
                        "type": "form",
                        "title": "激励配置",
                        "initApi": "/admin/plugin/epay/getConfig?type=params",
                        "api": "/admin/plugin/epay/saveConfig?type=params",
                        "actions": [
                            {
                                "type": "button",
                                "label": "取消",
                                "actionType": "close",
                            },
                            {
                                "type": "submit",
                                "label": "保存",
                                "level": "primary",
                            }
                        ],
                        onEvent: {
                            "submitSucc": {
                                "actions": [
                                    {
                                        "actionType": "custom",
                                        "script": `
                                        console.log(1231);\n //event.stopPropagation();`
                                    }
                                ]
                            }
                        },
                        "body": [
                            {
                                "type": "combo",
                                "name": "fields",
                                "label": "请求参数字段",
                                "items": [
                                    {
                                        "name": "field_name",
                                        "label": "字段名称",
                                        "type": "input-text",
                                        "required":true,
                                    },
                                    {
                                        "name": "field_value",
                                        "label": "字段默认值",
                                        "type": "input-text",
                                    },
                                    {
                                        "name": "filed_required",
                                        "type": "radios",
                                        "label": "radios",
                                        "options": [
                                            {
                                                "label":"是",
                                                "value":true,
                                            },
                                            {
                                                "label":"否",
                                                "value":false,
                                            },
                                        ]
                                    },
                                    {
                                        "label": "映射字段",
                                        "type": "select",
                                        "name": "field_mapping",
                                        "options": [
                                            {
                                                "label": "A",
                                                "value": "a"
                                            },
                                            {
                                                "label": "B",
                                                "value": "b"
                                            },
                                            {
                                                "label": "C",
                                                "value": "c"
                                            }
                                        ]
                                    }
                                ]
                            },
                        ]
                    }
                }
            ]
        }
    };
    window.jsonpCallback && window.jsonpCallback(response);
})();
