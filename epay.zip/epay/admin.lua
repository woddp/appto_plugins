local app = require("app")
local inspect = require("inspect")


function _config()
    local data = app.readJSON("data.json")
    if data==nil then
        data={
            account={
            },
            params={
            },
        }
    end
    return data
end

function getConfig()
    local query =  app.request("query")
    local type=rawget(query, "type") ~= nil and query.type or ""
    return app.outJSON(0,"ok",_config()[type])
end

function saveConfig()
    local query =  app.request("query")
    local type=rawget(query, "type") ~= nil and query.type or ""
    local form= app.request("form")

    local config=_config()
    if type=="account" then
        config.account=form
    end
    if type=="params" then
        config.params=form
    end
    app.saveJSON("data.json",config)
    return app.outJSON(0,"ok",nil)
end
