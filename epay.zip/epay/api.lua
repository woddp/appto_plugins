local app = require("app")
local inspect = require("inspect")
local http = require("http")
local json = require("json")
function getConfig()
    local data = app.readJSON("data.json")
    local pluginInfo = app.getPluginInfo()
    pay_buy_vip_select = rawget(data, "pay_buy_vip_select") ~= nil and data.pay_buy_vip_select or {  }
    local yiTypes = {
        alipay = "支付宝",
        tenpay = "财付通",
        qqpay = "QQ钱包",
        wxpay = "微信支付",
        alipaycode = "支付宝扫码",
        jdpay = "京东支付",
    }
    local pays = {}
    for _, v in ipairs(pay_buy_vip_select) do
        table.insert(pays, {
            type = v,
            label = pluginInfo.title .. "-" .. yiTypes[v],
            value = pluginInfo.name .. "," .. v,
            name = yiTypes[v]
        })
    end
    return json.encode(pays)
end

function test()

    app.apiJSON(1,"123", {  })

end