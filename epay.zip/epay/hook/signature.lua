local crypto = require("crypto")
local http = require("http")

-- 自定义排序函数
local function ksort(t)
    local keys = {}
    for k, _ in pairs(t) do
        table.insert(keys, k)
    end
    table.sort(keys)
    return keys
end

-- 计算签名的方法
local function createSign(params,key)
    ---- 获取按字母排序的键数组
    local sortedKeys = ksort(params)
    ---- 构建签名字符串
    local signstr = ''
    for _, k in ipairs(sortedKeys) do
        local v = params[k]
        if k ~= "sign" and k ~= "sign_type" and v ~= '' then
            signstr = signstr .. k .. '=' .. v .. '&'
        end
    end
    -- 移除末尾的 '&' 字符
    signstr = string.sub(signstr, 1, -2)
    -- 添加密钥
    signstr = signstr .. key
    -- 计算签名
    local sign = crypto.md5(signstr)
    params.sign=sign
    params.sign_type="MD5"
    return params
end

-- 自定义函数，用于构建查询字符串
local function httpBuildQuery(params)
    local query_string = ""
    for key, value in pairs(params) do
        if query_string ~= "" then
            query_string = query_string .. "&"
        end
        query_string = query_string .. key .. "=" .. http.query_escape(value)
    end
    return query_string
end

return {
    createSign=createSign,
    httpBuildQuery=httpBuildQuery
}