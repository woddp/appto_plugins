local app = require("app")
local inspect = require("inspect")
local http = require("http")
local json = require("json")
local history_service = require("history_service")

function getConfig()
    local data = app.readJSON("data.json")
    if data == nil then
        data = {
            max_num = 0,
        }
    end
    return json.encode({
        max_num = data.max_num,
    })
end

function add()

    local form = app.request("form")
    local userInfo = app.request("userInfo")
    -- 读取配置文件
    local config = app.readJSON("data.json")
    if userInfo.UserId <= 0 then
        return app.apiJSON(422, "请登录", nil)
    end

    if tonumber(form.videoId) <= 0 then
        return app.apiJSON(422, "参数错误", nil)
    end

    local count = history_service.count(userInfo.UserId, form.videoId)


    -- 使用os.date函数格式化日期时间
    form.updatedAt = form.updatedAt/1000
    form.createdAt = form.createdAt/1000

    if count > 0 then

        local err = history_service.update(userInfo.UserId, form)
        if err ~= nil then
            return app.apiJSON(0, "更新失败:" .. err, nil)
        end

    else
        local err = history_service.insert(userInfo.UserId, form)
        if err ~= nil then
            return app.apiJSON(0, "更新失败:" .. err, nil)
        end
    end


    history_service.checkMaxNum(userInfo.UserId,config.max_num)

    return app.apiJSON(1, "ok", nil)


end

function remove()
    local form = app.request("form")

    local userInfo = app.request("userInfo")

    if userInfo.UserId <= 0 then
        return app.apiJSON(422, "请登录", nil)
    end

    if tonumber(form.type) == 1 then
        if form.ids == "" then
            return app.apiJSON(422, "参数错误", nil)
        end
        app.mysql():exec(string.format("DELETE FROM mac_appto_plugin_cloud_history where user_id=%s and  video_id in (%s)", userInfo.UserId, form.ids))
    end
    if tonumber(form.type) == 2 then
        app.mysql():exec(string.format("DELETE FROM mac_appto_plugin_cloud_history where user_id=%s ", userInfo.UserId))
    end
    return app.apiJSON(1, "ok", nil)
end


function getHistoriesByPage()
    local form = app.request("query")
    local userInfo = app.request("userInfo")
    if userInfo.UserId <= 0 then
        return app.apiJSON(422, "请登录", nil)
    end
    local  data=history_service.getHistoriesByPage(userInfo.UserId,form.page)
    return app.apiJSON(1, "ok", data)
end
function getRecordById()
    local form = app.request("query")
    local userInfo = app.request("userInfo")
    if userInfo.UserId <= 0 then
        return app.apiJSON(422, "请登录", nil)
    end

    local  data=history_service.getRecordById(userInfo.UserId,form.video_id)
    return app.apiJSON(1, "ok", data)
end
function getRecord()
    local form = app.request("query")
    local userInfo = app.request("userInfo")
    if userInfo.UserId <= 0 then
        return app.apiJSON(422, "请登录", nil)
    end

    local  data=history_service.getRecord(userInfo.UserId,form.video_id,form.set_url)
    return app.apiJSON(1, "ok", data)

end
function getLatestRecord()
    local userInfo = app.request("userInfo")
    if userInfo.UserId <= 0 then
        return app.apiJSON(422, "请登录", nil)
    end
    local  data=history_service.getLatestRecord(userInfo.UserId)
    return app.apiJSON(1, "ok", data)
end

--同步本地数据
function sync()

    --登录后自动同步观看历史记录至服务器
    --存在的视频就更新 不存在就插入
    --超过配置条数按时间排序删除之前的
    local form = app.request("form")
    local userInfo = app.request("userInfo")
    local items = json.decode(form.data)

    if userInfo.UserId <= 0 then
        return app.apiJSON(422, "请登录", nil)
    end

    --清楚本地数据
    --history_service.clearAll(userInfo.UserId)

    for _, v in ipairs(items) do
        v.updatedAt = v.updatedAt/1000
        v.createdAt = v.createdAt/1000

        local count = history_service.count(userInfo.UserId, v.videoId)
        if count > 0 then
            local err = history_service.update(userInfo.UserId, v)
            if err ~= nil then
                goto continue
            end

        else
            local err = history_service.insert(userInfo.UserId, v)
            if err ~= nil then
                goto continue
            end
        end
        ::continue::
    end

    local config = app.readJSON("data.json")
    history_service.checkMaxNum(userInfo.UserId,config.max_num)

    return app.apiJSON(1, "ok", nil)
end

--获取所有数据
function getAll()

    local form = app.request("query")

    if tonumber(form.id)<= 0 then
        return app.apiJSON(422, "请登录", nil)
    end

    local resultLists,_ = app.mysql():query(string.format("select * from mac_appto_plugin_cloud_history where user_id=%s",form.id))

    local items={}

    for _, row in ipairs(resultLists.rows) do
        local entry = {}
        for i, column in ipairs(resultLists.columns) do
            entry[column] = row[i]
        end
        table.insert(items, entry)
    end

    return app.apiJSON(1,"ok",items);
end


