local app = require("app")

function handle()
    local sql=[[CREATE TABLE If Not Exists  `mac_appto_plugin_cloud_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `video_id` int DEFAULT '0',
  `video_cover` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `video_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `video_from` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `video_from_text` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `video_set_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `video_set_url` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `position` int DEFAULT '0',
  `duration` int DEFAULT '0',
  `created_at` int DEFAULT '0',
  `updated_at` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id_video_id` (`user_id`,`video_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;]]

    local _, err=app.mysql():exec(sql)

    if err~=nil then
        return "创建表失败"..err
    end
    return "ok"

end