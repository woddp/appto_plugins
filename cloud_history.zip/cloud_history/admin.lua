local app = require("app")
local inspect = require("inspect")
local app_utils = require("app_utils")
function getConfig()
    -- 读取 JSON 数据
    local data = app.readJSON("data.json")
    if data==nil then
        data={
            max_num=0,
        }
    end
    return app.outJSON(0,"ok",data)
end

function saveConfig()
    local form= app.request("form")

    app.saveJSON("data.json",{
        max_num=rawget(form, "max_num") ~= nil and form.max_num or 0,
    })
    return app.outJSON(0,"ok",nil)
end


function history()
    local form= app.request("query")

    local  user_id=rawget(form, "user_id") ~= nil and form.user_id or 0;
    local  page=rawget(form, "page") ~= nil and form.page or 1;
    local  limit=rawget(form, "perPage") ~= nil and form.perPage or 20;

    local whereQuery=""
    if tonumber(user_id)~=nil and tonumber(user_id)>0 then
        whereQuery=string.format(" where user_id = %s ", user_id)
    end
    local resultTotal, _ = app.mysql():query(string.format("select count(id) as count from mac_appto_plugin_cloud_history   %s ", whereQuery))

    local  total=tonumber(resultTotal.rows[1][1])

    local resultLists, _ = app.mysql():query(string.format("select * from mac_appto_plugin_cloud_history %s order by user_id,updated_at desc limit %s,%s", whereQuery, app_utils.paging(limit,page),limit))



    local items={}

    for _, row in ipairs(resultLists.rows) do
        local entry = {}
        for i, column in ipairs(resultLists.columns) do
            entry[column] = row[i]
        end
        table.insert(items, entry)
    end

    return app.outJSON(0,"ok",{
        total=total,
        items=items
    })

end

function delete()
    local form= app.request("query")
    local  ids=rawget(form, "ids") ~= nil and form.ids or "";
    if ids == "" then
        return app.outJSON(1, "没有选择数据", nil)
    end
    app.mysql():exec(string.format("DELETE FROM mac_appto_plugin_cloud_history where  id in (%s)", ids))
    return app.outJSON(0,"ok",nil)
end