local app = require("app")
local app_utils = require("app_utils")
-- 视频是否存在

local function count(userId, videoId)
    local result,err = app.mysql():query(string.format("select count(id) as count from mac_appto_plugin_cloud_history where user_id=%s and video_id=%s ", userId, videoId))
    if err ~= nil then
        return 0
    end
    return tonumber(result.rows[1][1])
end
local function update(userId, videoInfo)
    --   todo update
    local stmt, err = app.mysql():stmt("update mac_appto_plugin_cloud_history set video_from=?,video_from_text=?,video_set_name=?, video_set_url=?,position=?, duration=?, updated_at=? where user_id=? and video_id=? ")
    if err ~= nil then
        return err
    end
    _, err = stmt:exec(videoInfo.videoFrom, videoInfo.videoFromText, videoInfo.videoSetName, videoInfo.videoSetUrl, videoInfo.position, videoInfo.duration, videoInfo.updatedAt, userId, videoInfo.videoId)

    if err ~= nil then
        return err
    end
    return nil
end

local function insert(userId, videoInfo)
    local stmt, err = app.mysql():stmt([[
    INSERT INTO mac_appto_plugin_cloud_history
    ( `user_id`,`video_id`, `video_name`, `video_cover`, `video_from`, `video_from_text`, `video_set_name`, `video_set_url`, `position`, `duration`, `created_at`, `updated_at`)
    VALUES
    (?, ?, ?, ?,?, ?, ?, ?,?, ?, ?, ?);
]])
    if err ~= nil then
        return err
    end
    _, err = stmt:exec(userId,
            videoInfo.videoId,
            videoInfo.videoName,
            videoInfo.videoCover,
            videoInfo.videoFrom,
            videoInfo.videoFromText,
            videoInfo.videoSetName,
            videoInfo.videoSetUrl,
            videoInfo.position,
            videoInfo.duration,
            videoInfo.createdAt,
            videoInfo.updatedAt)

    if err ~= nil then
        return err
    end
    return nil
end
local function clearAll(userId)
    app.mysql():exec(string.format("DELETE FROM mac_appto_plugin_cloud_history where user_id= %s ", userId))
end

local function checkMaxNum(userId,maxNum)
    if maxNum <= 0 then
        return
    end
    local resultTotal, _ = app.mysql():query(string.format("select count(id) as count from mac_appto_plugin_cloud_history where user_id=%s ", userId))
    local total = tonumber(resultTotal.rows[1][1])
    if total > maxNum then
        app.mysql():exec(string.format("DELETE FROM mac_appto_plugin_cloud_history where user_id= %s  ORDER BY id LIMIT %s", userId, total - maxNum))
    end
end


local function getHistoriesByPage(userId,page)

    local resultLists, _ = app.mysql():query(string.format("select * from mac_appto_plugin_cloud_history where user_id=%s order by updated_at desc limit %s,%s", userId, (page-1)*20,20))
    local items={}
    for _, row in ipairs(resultLists.rows) do
        local entry = {}
        for i, column in ipairs(resultLists.columns) do
            entry[column] = row[i]
        end
        table.insert(items, entry)
    end
    return items
end
local function getRecordById(userId,videoId)
    local result,_ = app.mysql():query(string.format("select *  from mac_appto_plugin_cloud_history where user_id=%s and video_id=%s ", userId, videoId))
    return returnBuild(result )
end

local function getRecord(userId,videoId,setUrl)
    local result,_ = app.mysql():query(string.format("select *  from mac_appto_plugin_cloud_history where user_id=%s and video_id=%s and video_set_url=%s ", userId, videoId,setUrl))
    return returnBuild(result )
end
local function getLatestRecord(userId)
    local result,_  = app.mysql():query(string.format("select *  from mac_appto_plugin_cloud_history where user_id=%s order by updated_at desc limit 1 ", userId))

    return returnBuild(result )
end

function returnBuild(result)
    local entry={}
    for _, row in ipairs(result.rows) do
        for i, column in ipairs(result.columns) do
            entry[column] = row[i]
        end
    end
    if next(entry)==nil then
        return nil
    end
    return entry
end

return {
    count=count,
    update=update,
    insert=insert,
    clearAll=clearAll,
    checkMaxNum=checkMaxNum,
    getHistoriesByPage=getHistoriesByPage,
    getRecordById=getRecordById,
    getRecord=getRecord,
    getLatestRecord=getLatestRecord,
}