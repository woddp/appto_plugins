(function () {


    let response = {
        type: "page",
        body: {
            "type": "tabs",
            "tabs": [
                {
                    "title": "观看记录",
                    "tab": {
                        "type": "page",
                        "body": {
                            "type": "crud",
                            "api": window.buildUrl("plugin/cloud_history/history"),
                            "syncLocation": true,
                            "filter": {
                                "title": "条件搜索",
                                "body": [
                                    {
                                        "type": "group",
                                        "body": [
                                            {
                                                "type": "input-text",
                                                "name": "user_id",
                                                "label": "用户id",
                                                "clearable": true,
                                                "size": "sm"
                                            },

                                        ]
                                    }
                                ],
                            },
                            "bulkActions": [
                                {
                                    "label": "批量删除",
                                    "actionType": "ajax",
                                    "api": "get:"+window.buildUrl("plugin/cloud_history/delete?ids="+"${ids|raw}"),
                                    "confirmText": "确定要批量删除?"
                                },
                            ],
                            "columns": [
                                {
                                    "name": "id",
                                    "label": "ID"
                                },
                                {
                                    "name": "user_id",
                                    "label": "用户id"
                                },
                                {
                                    "name": "video_id",
                                    "label": "视频id"
                                },
                                {
                                    "name": "video_name",
                                    "label": "视频名称"
                                },

                                {
                                    "type": "static-image",
                                    "name": "video_cover",
                                    "label": "视频图片",
                                    "thumbRatio": "1:1",
                                    "thumbMode": "cover"
                                },
                                {
                                    "name": "video_from_text",
                                    "label": "播放源"
                                },
                                {
                                    "name": "video_set_name",
                                    "label": "播放集数"
                                },
                            ]
                        }
                    }
                },
                {
                    "title": "配置",
                    "tab": {
                        "type": "form",
                        "initApi": window.buildUrl("plugin/cloud_history/getConfig"),
                        "api": window.buildUrl("plugin/cloud_history/saveConfig"),
                        "body": [
                            {
                                "type": "input-number",
                                "name": "max_num",
                                "max": 200,
                                "min": 1,
                                "required": true,
                                "label": "历史记录最大数量（最大200条）："
                            }
                        ]
                    }
                }
            ]
        }
    };
    window.jsonpCallback && window.jsonpCallback(response);
})();
